# 🍳 Kitchen Recipe Manager - Setup Instructions

## 📋 What You Have

This folder contains:
- `recipe-manager-voice.html` - The main app (voice-enabled)
- `start_server.py` - Python web server script
- `START_SERVER.bat` - Windows launcher (double-click this!)
- `start_server.sh` - Mac/Linux launcher
- `README.md` - This file

---

## 🚀 Quick Start

### **Windows Users:**
1. **Double-click `START_SERVER.bat`**
2. A command window will open
3. Your browser should open automatically
4. If not, open Chrome/Edge and go to: `http://localhost:8000/recipe-manager-voice.html`

### **Mac/Linux Users:**
1. Open Terminal
2. Navigate to this folder: `cd /path/to/folder`
3. Run: `./start_server.sh`
4. Open Chrome/Edge and go to: `http://localhost:8000/recipe-manager-voice.html`

---

## ⚙️ Requirements

### **Python**
- **Windows**: Download from https://www.python.org/downloads/
  - ⚠️ During installation, CHECK the box "Add Python to PATH"
- **Mac**: Already installed, or install via Homebrew: `brew install python3`
- **Linux**: Install via package manager: `sudo apt install python3`

### **Browser**
- ✅ **Chrome** (Recommended)
- ✅ **Edge** (Recommended)
- ⚠️ **Firefox** (Limited support)
- ❌ **Safari** (Not supported)

---

## 🎤 Setting Up Your USB Microphone

### **Windows:**
1. Plug in your USB camera/microphone
2. Right-click speaker icon in taskbar → "Sound settings"
3. Under "Input", select your USB microphone as default
4. Test by speaking - you should see the input level meter move

### **Mac:**
1. Plug in your USB camera/microphone
2. System Preferences → Sound → Input tab
3. Select your USB microphone
4. Speak and watch the input level bars

### **Linux:**
1. Plug in your USB camera/microphone
2. Settings → Sound → Input
3. Select your USB microphone

---

## 🔒 Browser Permissions

When you first use voice input:

1. Browser will show a permission prompt: **"Allow microphone access?"**
2. Click **"Allow"**
3. If you accidentally clicked "Block":
   - Chrome: Click the 🔒 icon in address bar → Microphone → "Allow"
   - Edge: Same as Chrome
   - Then reload the page

---

## ✅ Testing Voice Input

1. Start the server (see Quick Start above)
2. Open the app in Chrome/Edge at `http://localhost:8000/recipe-manager-voice.html`
3. Click on "Classic Tomato Sauce" recipe
4. Double-click any ingredient field
5. Click the 🎤 button (it should start pulsing)
6. **Speak clearly**: "two hundred fifty grams"
7. Text should appear in real-time as you speak!
8. Click ✓ (Send) to save

---

## 🐛 Troubleshooting

### **"Python is not installed" error**
→ Install Python (see Requirements above)  
→ Make sure "Add Python to PATH" was checked during installation  
→ Restart your computer after installing

### **"Port 8000 already in use" error**
→ Close other programs using port 8000  
→ Or edit `start_server.py` and change `PORT = 8000` to `PORT = 8001`

### **Voice input not working**
→ Check you're using `http://localhost:8000` (NOT opening the file directly)  
→ Check browser is Chrome or Edge  
→ Check microphone permissions (see Browser Permissions above)  
→ Check USB microphone is plugged in and set as default  
→ Open browser console (F12) to see error messages

### **Microphone permission denied**
→ Click 🔒 icon in address bar  
→ Change Microphone from "Block" to "Allow"  
→ Reload the page

### **No sound detected**
→ Check microphone is set as system default  
→ Test microphone in system sound settings first  
→ Make sure no other app is using the microphone  
→ Try unplugging and replugging USB microphone

### **Browser opens but shows error**
→ Make sure server is still running (command window open)  
→ Try refreshing the page (F5 or Ctrl+R)  
→ Check the URL is exactly: `http://localhost:8000/recipe-manager-voice.html`

---

## 📖 How to Use the App

### **Basic Navigation:**
- **Recipe List**: Click any recipe to view details
- **Search**: Type recipe name in search bar
- **New Recipe**: Click "+ New" button, select category
- **Back**: Click "← Back" to return to recipe list

### **Voice Input:**
1. Double-click any field to edit
2. Click 🎤 button (starts pulsing = listening)
3. Speak naturally
4. Text appears in real-time
5. Click ✓ to save or ✕ to clear and re-speak

### **Keyboard Input:**
1. Double-click any field to edit
2. Type your text
3. Press Enter or click ✓ to save

### **Editing Recipes:**
- **Recipe Name**: Click name to edit
- **Portions**: Change number (ingredients auto-scale!)
- **Ingredients**: Click any cell in the 4-column grid
- **Method Steps**: Click any step to edit
- **Plating**: Click any instruction to edit

### **Adding Items:**
- Click "+ Add Ingredient" to add new ingredient
- Click "+ Add Step" to add method step
- Click "+ Add Plating Instruction" to add plating step

### **Timer:**
- Click ⏱️ button in menu
- Enter seconds
- Click "Start Timer"
- Alert when time's up!

---

## 🎯 Tips for Best Results

### **Voice Recognition:**
- Speak at **normal conversational pace**
- **Pause between phrases** for better accuracy
- Works well with **moderate background noise**
- **Bring USB mic close to your mouth** for best results
- Browser adds **automatic punctuation**
- Say "period" or "comma" for explicit punctuation

### **Kitchen Use:**
- External USB microphone is **much better** than tablet's built-in mic
- Position microphone away from loud equipment (fans, mixers)
- Keep screen on using the app's built-in setting
- Use voice input for hands-free editing while cooking

---

## 🔧 Advanced Options

### **Change Server Port:**
Edit `start_server.py`, line 10:
```python
PORT = 8000  # Change to any port (e.g., 8080, 3000, etc.)
```

### **Access from Another Device:**
Find your computer's IP address:
- Windows: `ipconfig` in Command Prompt
- Mac/Linux: `ifconfig` in Terminal

Then on another device (tablet, phone) on same network:
```
http://YOUR_IP_ADDRESS:8000/recipe-manager-voice.html
```
Example: `http://192.168.1.100:8000/recipe-manager-voice.html`

⚠️ Voice input requires HTTPS for remote access (localhost exception only)

---

## 📞 Need Help?

1. **Check browser console**: Press F12, look for errors in Console tab
2. **Check server output**: Look at the command window where server is running
3. **Test with simple HTML**: Create a minimal test page to isolate issues
4. **Browser compatibility**: Make sure you're using Chrome or Edge

---

## 🎉 You're Ready!

Start the server and enjoy voice-controlled recipe management! 👨‍🍳🎤

**Remember**: 
- Keep the command window open while using the app
- Press Ctrl+C in the command window to stop the server
- Always access via `http://localhost:8000` (not by opening HTML file directly)

Happy cooking! 🍳✨
